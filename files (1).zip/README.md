# AI-Based Personalized Travel Planning & Recommendation System for Sri Lanka
### Regression module — Hotel/Dining Price (ADR) Estimator

This folder contains the regression sub-component of the wider AI-based, context-aware
tourism recommendation system: a model that predicts the **Average Daily Rate (ADR)** a
traveller is likely to pay for a stay, given trip characteristics. It is deployed as a
Streamlit web app.

## Files

| File | Purpose |
|---|---|
| `hotel_adr_regression.ipynb` | Colab/Jupyter notebook: loads the dataset, cleans it, engineers features, trains and compares three regressors, and exports `model.pkl`. |
| `model.pkl` | Trained scikit-learn pipeline (preprocessing + regressor), produced by running the notebook. **Not included until you run the notebook once** — see below. |
| `app.py` | Streamlit front-end that loads `model.pkl` and predicts ADR from user-entered trip details. |
| `requirements.txt` | Python dependencies for the Streamlit app. |

## Dataset

**Hotel Booking Demand** (Antonio, Almeida & Nunes, 2019, *Data in Brief*, vol. 22), mirrored
on Kaggle as [`jessemostipak/hotel-booking-demand`](https://www.kaggle.com/datasets/jessemostipak/hotel-booking-demand)
and publicly hosted (no auth needed) via the TidyTuesday project at:

```
https://raw.githubusercontent.com/rfordatascience/tidytuesday/main/data/2020/2020-02-11/hotels.csv
```

A Sri Lanka–specific hotel-pricing dataset with a continuous target is not currently available
as an open Kaggle dataset, so this globally-used, well-documented hospitality dataset is used
as the proxy for the ADR-prediction task. The notebook's `DATA_URL` variable can be swapped for
a Sri Lankan hotel-booking export with the same columns (hotel type, lead time, stay length,
party size, meal plan, market segment, room type, ADR) without changing the rest of the pipeline.

## Step 1 — Run the notebook and produce `model.pkl`

1. Open `hotel_adr_regression.ipynb` in [Google Colab](https://colab.research.google.com/) (File → Upload notebook) or Jupyter.
2. Run all cells top to bottom (Runtime → Run all). This will:
   - Download the dataset directly from the URL above.
   - Clean the data (handle missing values, drop leakage columns, remove invalid/duplicate rows).
   - Engineer numeric and categorical features.
   - Train Linear Regression, Random Forest, and Gradient Boosting models and compare MAE / RMSE / R².
   - Save the best-performing pipeline as `model.pkl` in the Colab working directory.
3. Download `model.pkl` from the Colab file browser (left sidebar → folder icon → right-click `model.pkl` → Download).

## Step 2 — Assemble the GitHub repository

1. Create a new **public** GitHub repository (e.g. `sri-lanka-travel-regression`).
2. Add these four files to the repo root:
   - `app.py`
   - `requirements.txt`
   - `model.pkl` (downloaded from Colab in Step 1)
   - `hotel_adr_regression.ipynb` (for reference/reproducibility)
3. Commit and push:
   ```bash
   git init
   git add app.py requirements.txt model.pkl hotel_adr_regression.ipynb
   git commit -m "Add ADR regression model and Streamlit app"
   git branch -M main
   git remote add origin https://github.com/<your-username>/sri-lanka-travel-regression.git
   git push -u origin main
   ```

## Step 3 — Deploy on Streamlit Community Cloud

1. Go to [share.streamlit.io](https://share.streamlit.io/) and sign in with GitHub.
2. Click **"New app"**.
3. Select your repository, the `main` branch, and set the main file path to `app.py`.
4. Click **Deploy**. Streamlit Cloud will install `requirements.txt` and launch the app; you'll get a
   public URL such as `https://<your-app-name>.streamlit.app`.
5. Any future `git push` to `main` will automatically redeploy the app.

## Local test (optional, before deploying)

```bash
pip install -r requirements.txt
streamlit run app.py
```

## How this fits the wider system

This regression module estimates trip cost as one contextual input into the broader
context-aware recommendation engine described in the dissertation proposal and supporting
reports (hotel/dining selection, transport planning, monsoon- and Poya-day-aware trip
scheduling). Budget fit, alongside weather and transit context, is one of the constraints
the full system uses to shortlist and rank recommendations for a traveller.
